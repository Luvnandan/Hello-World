import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.*;
import java.awt.*;
import java.util.Date;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import java.util.*;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;





public class CQAC extends JFrame implements ActionListener
{

        ArrayList<String> input = new ArrayList<String>();// declaring an array list


             // declaring all buttons, labels and textfields

	    private JLabel titleLabel = new JLabel("CQ Air Conditioning"); // program title

	    private JLabel lblStudentId = new JLabel("Student Id : 12095338");  // displaying student id and name
        private JLabel lblStudentName = new JLabel("Student Name: Luvnandan Singla");

	    private JLabel lblTechnicianName =  new JLabel("Technician Name");
	    private JTextField txtTechnicianName = new JTextField(15);

	    private JLabel lblContactNumber = new JLabel("Technician Contact Number");
	    private JTextField txtContactNumber = new JTextField(15);

	    private JLabel lblBuildingAddress = new JLabel("Building Address ");
	    private JTextField txtBuildingAddress = new JTextField(15);

	    private JLabel lblHorsePower = new JLabel("Horse Power of AC");
	    private JTextField txtHorsePower = new JTextField(15);

	    private JLabel lblZones = new JLabel("Number of Zones");
	    private JTextField txtZones = new JTextField(15);

	    private JLabel lblOutlets = new JLabel("Number of Outlets");
	    private JTextField txtOutlets = new JTextField(15);

	    private JLabel lblstartDate = new JLabel("Start Date");
	    private JTextField txtstartDate = new JTextField(15);

	    private JLabel lblendDate = new JLabel("End Date");
	    private JTextField txtendDate = new JTextField(15);

	    private JPanel panelArea;
	    private JPanel panelINFOR;   // declaring panel
	    private JPanel panelArea1;
	    private JPanel panelLast;


     //   private JScrollPane scrollPane1;
	    private JTextArea displayTextArea = new JTextArea("",20, 30); // declare text area
	    private JTextArea displayTextArea1 = new JTextArea("", 20,30);
	    private JScrollPane scrollPane1;
	    private JScrollPane scrollPane; // scroll pane for the text area

	   //  declare all of the buttons
	    private JButton enterButton = new JButton("Enter");
	    private JButton clearButton = new JButton("Clear All");
	    private JButton searchButton = new JButton("Search");
	    private JButton exitButton = new JButton("Exit");


	   public CQAC()
	   { // constructor create the Gui

			this.setLayout(new FlowLayout());			// set JFrame to FlowLayout
			panelArea1 = new JPanel();
             panelArea1.setLayout(new BorderLayout());
        	 panelINFOR = new JPanel();
        	 panelINFOR.setLayout(new GridLayout(10, 1));
             panelArea = new JPanel();
			 panelArea.setLayout(new BorderLayout());
			 panelLast = new JPanel(new GridBagLayout());
			 GridBagConstraints c = new GridBagConstraints();
			titleLabel.setFont(new Font("Ariel", Font.BOLD, 22));
			 add(titleLabel);
			 add(lblStudentId);
			 add(lblStudentName);
			  panelArea.add(displayTextArea1);
			 panelINFOR.add(lblTechnicianName);
			 panelINFOR.add(txtTechnicianName);
			 panelINFOR.add(lblContactNumber);
			 panelINFOR.add(txtContactNumber);
			 panelINFOR.add(lblBuildingAddress);
			 panelINFOR.add(txtBuildingAddress);
			 panelINFOR.add(lblHorsePower);
			 panelINFOR.add(txtHorsePower);
			 panelINFOR.add(lblZones);
			 panelINFOR.add(txtZones);
			 panelINFOR.add(lblOutlets);
			 panelINFOR.add(txtOutlets);
			 panelINFOR.add(lblstartDate);
			 panelINFOR.add(txtstartDate);
			 panelINFOR.add(lblendDate);
	     	 panelINFOR.add(txtendDate);

	     	 panelArea1.add(displayTextArea);
	     	c.gridx=0;
	     	c.gridy=1;
			panelLast.add(panelArea, c);
			c.gridx=0;
			c.gridy=2;
			panelLast.add(panelINFOR, c);
			c.gridx=0;
			c.gridy=3;
			panelLast.add(panelArea1, c);
	     	panelArea.setPreferredSize(new Dimension(80,150));
	     	 panelArea1.setMinimumSize(panelArea1.getPreferredSize());
	     	panelArea1.setPreferredSize(new Dimension(80,150));
	   		 panelINFOR.setPreferredSize(new Dimension(250, 250));
	       	 panelINFOR.setMaximumSize(panelINFOR.getPreferredSize());
         	 panelArea.setMinimumSize(panelArea.getPreferredSize());

             this.add(panelArea);
             this.add(panelINFOR);
             this.add(panelArea1);
             this.add(panelLast);



		// set text area to a monospaced font so the columns can be aligned using a format string
			displayTextArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
			displayTextArea.setEditable(false); 			// make text area read only
				displayTextArea1.setFont(new Font("Monospaced", Font.PLAIN, 12));
			displayTextArea1.setEditable(false); 			//

			scrollPane = new JScrollPane(displayTextArea); 	// add text area to the scroll pane
			scrollPane1 = new JScrollPane(displayTextArea1);
				scrollPane1.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER); // just need vertical scrolling

			//scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER); // just need vertical scrolling
			add(scrollPane);
			add(scrollPane1);
			add(enterButton);
			add(clearButton);
		    add(searchButton);
			add(exitButton);

			enterButton.addActionListener(this);		// add the action listener to the buttons
			clearButton.addActionListener(this);
			searchButton.addActionListener(this);
			exitButton.addActionListener(this);



		// when the user pushes the system close (X top right corner)
			addWindowListener( // override window closing method
			new WindowAdapter()
			{
				public void windowClosing(WindowEvent e)
				{
					exit();				// Attempt to exit application
				}
			}
		);

		try{
			FileReader fw= new FileReader("D:\\testout.txt");
			BufferedReader br = new BufferedReader(fw);
           String line;
		  while((line = br.readLine()) != null)
{
    displayTextArea1.append(line+"\n");
}
br.close();
		}catch(Exception e){System.out.print(e);}
	}



		public void actionPerformed(ActionEvent e)
		{ // process the clicks on all of the buttons
			String command = e.getActionCommand();

			if (command.compareTo("Enter") == 0)
				enter();
			else if (command.compareTo("Clear All") == 0)
 			    clear();
		   else if (command.compareTo("Search") == 0)
		       search();
			else if (command.compareTo("Exit") == 0)
				exit();
	}


		private void enter()
		{

    	   if (txtTechnicianName.getText().compareTo("") == 0 && txtContactNumber.getText().compareTo("") == 0)
    	     {
			 	JOptionPane.showMessageDialog(null,"You must fill technician's details", "CQ Air Conditioning" , JOptionPane.ERROR_MESSAGE);
				txtTechnicianName.requestFocus();		//  put the focus back to the name field
			 	return; //leave the method after the error
			 }


    	   if (txtTechnicianName.getText().compareTo("") == 0)
    	     {
			 	JOptionPane.showMessageDialog(null,"You must enter a technician name", "CQ Air Conditioning" , JOptionPane.ERROR_MESSAGE);
				txtTechnicianName.requestFocus();	// put the focus back to the name field
			 	return; // leave the method after the error
			 }

    	   if (txtContactNumber.getText().compareTo("") == 0)
    	     {
			 	JOptionPane.showMessageDialog(null,"You must enter the contact Number" , "CQ Air Conditioning" , JOptionPane.ERROR_MESSAGE);
				txtContactNumber.requestFocus(); 		// put the focus back to the garments field
			 	return; // leave the method after the error

			 }

			if (txtBuildingAddress.getText().compareTo("") == 0)
			{
				JOptionPane.showMessageDialog(null,"You must enter the Building's address", "CQ Air Conditioning", JOptionPane.ERROR_MESSAGE);
				txtBuildingAddress.requestFocus();
				return;
			}

			if (txtHorsePower.getText().compareTo("") == 0)
			{
				JOptionPane.showMessageDialog(null,"You must enter the Horse Power", "CQ Air Conditioning", JOptionPane.ERROR_MESSAGE);
				txtHorsePower.requestFocus();
				return;
			}

			if (txtZones.getText().compareTo("") == 0)
			{
				JOptionPane.showMessageDialog(null,"You must enter the number of zones", "CQ Air Conditioning", JOptionPane.ERROR_MESSAGE);
				txtZones.requestFocus();
				return;
			}

			if (txtOutlets.getText().compareTo("") == 0)
			{
				JOptionPane.showMessageDialog(null,"You must enter the number of outlets", "CQ Air Conditioning", JOptionPane.ERROR_MESSAGE);
				txtOutlets.requestFocus();
				return;
			}

			if (txtstartDate.getText().compareTo("") == 0)
			{
				JOptionPane.showMessageDialog(null,"You must enter the starting date of work", "CQ Air Conditioning", JOptionPane.ERROR_MESSAGE);
				txtstartDate.requestFocus();
				return;
			}

			if (txtendDate.getText().compareTo("") == 0)
			{
				JOptionPane.showMessageDialog(null,"You must enter the ending date", "CQ Air Conditioning", JOptionPane.ERROR_MESSAGE);
				txtendDate.requestFocus();
				return;
			}
           if (txtendDate.getText().compareTo("dd-MM-yyyy") !=0)
           {
			   JOptionPane.showMessageDialog(null,"enter correct format","CQ Air Conditioning", JOptionPane.ERROR_MESSAGE);
		        txtendDate.requestFocus();
		        return;
			}


    	    String technicianName = txtTechnicianName.getText();
    	    int ContactNumber = Integer.parseInt(txtContactNumber.getText());
    	    String BuildingAddress = txtBuildingAddress.getText();
    	    int HorsePower = Integer.parseInt(txtHorsePower.getText());
    	    int Zones = Integer.parseInt(txtZones.getText());
    	    int Outlets = Integer.parseInt(txtOutlets.getText());
    	    String StartDate = txtstartDate.getText();
    	    String EndDate = txtendDate.getText();

    	    	Building obj = new Building(BuildingAddress , HorsePower , Zones , Outlets);
			     		Technician obj1 = new Technician(technicianName , ContactNumber);
			     		Installation obj2 = new Installation(StartDate , EndDate);


    	     						 input.add("\nTechnician Name : " + technicianName);
						             input.add("\nContactNumber : " + ContactNumber);
						             input.add("\nBuilding Address : "+ BuildingAddress);
						             input.add("\nHorse Power : " + String.valueOf(HorsePower));
						             input.add("\nNumber Of Zones : " + String.valueOf(Zones));
						             input.add("\nNumber Of Outlets : " + String.valueOf(Outlets));
						             input.add("\nStarting Date : " + StartDate);
						             input.add("\nEnding Date : " + EndDate + "\n");
						             input.add("\nThe total cost of installation is "+obj.calculateCharge());
            			 input.add("-----------------------------------------------------");
            			 int num=input.size();

             try{
				 FileWriter fw=new FileWriter("D:\\testout.txt", true);
				 BufferedWriter br = new BufferedWriter(fw);
				 br.write("\nTechnician Name : " + technicianName);
				 br.write("\nContactNumber : " + ContactNumber);
				 br.write("\nBuilding Address : "+ BuildingAddress);
				 br.write("\nHorse Power : " + String.valueOf(HorsePower));
				 br.write("\nNumber Of Zones : " + String.valueOf(Zones));
				 br.write("\nNumber Of Outlets : " + String.valueOf(Outlets));
				 br.write("\nStarting Date : " + StartDate);
				 br.write("\nEnding Date : " + EndDate);
				 br.write("\nThe total cost of installation is "+obj.calculateCharge());

				 br.close();
				 fw.close();
				}catch(Exception e){System.out.print(e);}
				displayTextArea.append(String.format("\nSUCCESS\n"));
			try{
						FileReader fw= new FileReader("D:\\testout.txt");
						BufferedReader br = new BufferedReader(fw);
			           String line;
					  while((line = br.readLine()) != null)
			{
			    displayTextArea1.append(line+"\n");
			}
			br.close();
					}catch(Exception e){System.out.print(e);}




     	   displayTextArea.append(String.format(obj1.toString()));
     	   displayTextArea.append(String.format(obj.toString()));
     	   displayTextArea.append(String.format(obj2.toString()));
     	   displayTextArea.append(String.format("\nThe total cost of installation is "+obj.calculateCharge()));
     	   displayTextArea.append(String.format("\n\nHit the clear button if you want to make a new entry "));

		// Clear input fields and return focus to the customer name field and increment current booking variable

		}



    	public void clear()
 		{    // clearing the textfields and returning the focus back to the Name field
	 		 txtTechnicianName.requestFocus();
	         txtTechnicianName.setText("");
	         txtContactNumber.setText("");
	         txtBuildingAddress.setText("");
	         txtHorsePower.setText("");
	         txtZones.setText("");
	         txtOutlets.setText("");
	         txtstartDate.setText("");
	         txtendDate.setText("");
	         displayTextArea.setText("");
	    }

	  public void displayHeading()
		{

			for (int i = 0; i < input.size(); i++)
			{
			      displayTextArea.append(input.get(i));

            }
		}
	 public void search()
	 {


		 String techName;
		 techName = JOptionPane.showInputDialog(null,"enter search name");
		  Iterator itr=input.iterator();

			for(int i=0; i<input.size(); i++)
			{
				if (techName.equalsIgnoreCase(input.get(i)))
				{

                  displayTextArea.append(String.format(input.get(i)));
			    //  displayTextArea.append(input.get(i));
                return;
				}
			}
				}




		public void appendLine()
		{
			displayTextArea.append("-------------------------------------------------------\n");
		}



		private void exit()
		{
			// display exit message here
			JOptionPane.showMessageDialog(null,"Thank you for  using the CQ Air Conditioning System", "CQ Air Conditioning", JOptionPane.PLAIN_MESSAGE );

    	    System.exit(0);
		} // exit




		// Main method create instance of class
		public static void main(String[] args)
		{
			CQAC f = new CQAC();			// Create instance of class
			f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);	// allow the code to close the program
			f.setBounds(600,650, 850, 800);						// Define position and size of app
			f.setTitle("CQ Air Conditioning System");		// Set the title of the app
			f.setVisible(true);										// Make the application visible
			f.setResizable(false);									// Make the window not resizable

		} // main

}





