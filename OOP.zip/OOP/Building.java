public class Building
{

    private String buildingAddress;
    private int horsePower;
    private int numberOfZones;
    private int numberOfOutlets;

    public Building()
    {

    }

    public Building(String buildingAddress, int horsePower, int numberOfZones, int numberOfOutlets)
    {
        this.buildingAddress = buildingAddress;
        this.horsePower = horsePower;
        this.numberOfZones = numberOfZones;
        this.numberOfOutlets = numberOfOutlets;
    }

    public String getBuildingAddress()
    {
        return buildingAddress;
    }

    public int getHorsePower()
    {
        return horsePower;
    }

    public int getNumberOfZones()
    {
        return numberOfZones;
    }
    public int getNumberOfOutlets()
    {
        return numberOfOutlets;
    }


    public void setBuildingAddress(String buildingAddress)
    {
        this.buildingAddress = buildingAddress;
    }

    public void setHorsePower(int horsePower)
    {
        this.horsePower = horsePower;
    }

    public void setNumberOfZones(int numberOfZones)
    {
        this.numberOfZones = numberOfZones;
    }

    public void setNumberOfOutlets(int numberOfOutlets)
    {
        this.numberOfOutlets = numberOfOutlets;
    }

    public double calculateCharge()
			// calculateCharge
			{

				double CHARGE_PER_Zone = 8.50;
				double CHARGE_PER_OUTLET = 20.00;
				double HORSE_POWER_CHARGE = 6.50;
	            double charge = 0.0;

			    charge = CHARGE_PER_Zone*getNumberOfZones() + CHARGE_PER_OUTLET*getNumberOfOutlets() + HORSE_POWER_CHARGE*getHorsePower();

		        return charge;
		  }
		  @Override
    public String toString()
    {
        return "\nBuilding Address : " + this.buildingAddress + "\nHorse Power : " + this.horsePower + "\nNumber Of Zones : "+ this.numberOfZones + "\nNumber of Outlets : " + this.numberOfOutlets;
    }
}
