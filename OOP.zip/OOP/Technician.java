public class Technician
{

    private String name;
    private int contactNumber;


    public Technician()
    {

    }

    public Technician(String name, int contactNumber)
    {
        this.name = name;
        this.contactNumber = contactNumber;
    }

    public String getName()
    {
        return name;
    }

    public int getContactNumber()
    {
        return contactNumber;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public void setContactNumber(int contactNumber)
    {
        this.contactNumber = contactNumber;
    }

    public String toString()
    {
        return "Technician Name  : " + this.name +" \nContact Number : "+ this.contactNumber;
    }
}
